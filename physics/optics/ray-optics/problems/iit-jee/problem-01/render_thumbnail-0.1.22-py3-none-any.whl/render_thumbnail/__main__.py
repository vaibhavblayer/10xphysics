from .main import main
main(prog_name="render-thumbnail")
